//Utilize console.log() to output results 
const fName = "Flora Mae";
const lName = "Requillo";
const age = 20;
const birth = "October 02, 2003";

console.log("First Name: " + fName);
console.log("Last Name: " + lName);
console.log("Age: " + age);
console.log("Birthdate: " + birth);