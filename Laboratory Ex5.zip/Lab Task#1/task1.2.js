// Perform arithmetic operations
const addition = 5 + 5;
const subtraction = 20 - 10;
const multiplication = 5 * 2;
const division = 100/10;
const modulus = 10%100;

// Utilize console.log() to output results
console.log("Addition:", addition);
console.log("Subtraction:", subtraction);
console.log("Multiplication:", multiplication);
console.log("Division:", division); 
console.log("Modulus:", modulus);