// Declare variables of different data types
const name = "Flora Mae Requillo"; // string
const  age = 20; // number
const isStudent = true; // boolean

// Implement basic conditional statements
if (age > 18) {
  console.log("You are an adult.");
} else {
  console.log("You are not an adult.");
}

// Utilize console.log() to output results
console.log(`Welcome ${name}. You are ${age} years old!`);
