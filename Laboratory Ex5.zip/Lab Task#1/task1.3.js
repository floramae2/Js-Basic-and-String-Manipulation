//Implement basic conditional statements (if, else) to compare values.
const num1 = 50;
const num2= 20;

// Utilize console.log() to output results
if (num1 > num2) {
    console.log("First number is greater than the second number.");
} else if (num1 < num2) {
    console.log("First number is less than the second number.");
} else {
    console.log("Equal");
}
