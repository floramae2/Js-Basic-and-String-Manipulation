const userInput = prompt("Please enter a text:");

// Count characters
const charCount = userInput.length;

// Count words
const wordCount = userInput.split(/\s+/).filter(word => word.length > 0).length;

// Count sentences
const sentenceCount = userInput.match(/[^.!?]+[.!?]+/g) ? userInput.match(/[^.!?]+[.!?]+/g).length : 0;

console.log('You entered:' +' '+ userInput);
console.log(`Character count: ${charCount}`);
console.log(`Word count: ${wordCount}`);
console.log(`Sentence count: ${sentenceCount}`);