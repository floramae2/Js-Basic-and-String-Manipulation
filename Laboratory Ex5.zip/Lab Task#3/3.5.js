const userInput = prompt("Please enter a string of text:");

// Divide the input text into an array of words
const words = userInput.toLowerCase().split(/\s+/);

// Initialize variables to store the total number of characters and words
let totalChars = 0;
let wordCount = 0;

// Loop through the array of words
for (let i = 0; i < words.length; i++) {
  // Check if the current word is not an empty string
  if (words[i].length > 0) {
    // Add the length of the current word to the total
    totalChars += words[i].length;
    // Increment the word count
    wordCount++;
  }
}

// Initialize variables to store the most frequent word and its count
let mostFrequentWord = "";
let maxCount = 0;
const wordCounts = {};

// Loop through the array of words
for (let i = 0; i < words.length; i++) {
  // Check if the current word is not an empty string
  if (words[i].length > 0) {
    // Check if the current word is already in the wordCounts object
    if (wordCounts[words[i]]) {
      // If it is, increment its count
      wordCounts[words[i]]++;
    } else {
      // If it isn't, add it to the wordCounts object with a count of 1
      wordCounts[words[i]] = 1;
    }
    // Check if the count of the current word is greater than the current max count
    if (wordCounts[words[i]] > maxCount) {
      // If it is, update the most frequent word and its count
      mostFrequentWord = words[i];
      maxCount = wordCounts[words[i]];
    }
  }
}

// Initialize variables to store the total number of sentences and the number of periods, exclamation points, and question marks
let totalSentences = 0;
let punctuationCount = 0;

// Loop through the input text
for (let i = 0; i < userInput.length; i++) {
  // Check if the current character is a period, exclamation point, or question mark
  if (userInput[i] === "." || userInput[i] === "!" || userInput[i] === "?") {
    // Increment the punctuation count
    punctuationCount++;
  }
  // Check if the current character is a period and the next character is a space or the end of the input text
  if (userInput[i] === "." && (userInput[i+1] === " " || i === userInput.length-1)) {
    // Increment the sentence count
    totalSentences++;
  }
}

// Calculate the average word length
const avgWordLength = totalChars / wordCount;

// Output the analyzed results
console.log(`Number of characters: ${totalChars}`);
console.log(`Number of words: ${wordCount}`);
console.log(`Number of sentences: ${totalSentences}`);
console.log(`Most frequent word: ${mostFrequentWord} with a count of ${maxCount}`);
console.log(`Average word length: ${avgWordLength.toFixed(2)}`);