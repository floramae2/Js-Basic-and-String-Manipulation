//prompt the user to input a string of text
const userInput = prompt("Please enter a text:");
console.log(`You entered: ${userInput}`);