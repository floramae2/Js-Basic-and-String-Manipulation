const userInput = prompt("Please enter a string of text:");

// Divide the input text into an array of words
const words = userInput.toLowerCase().match(/\b\w+\b/g);

// Calculate the total number of characters in all words
let totalChars = 0;
for (const word of words) {
  totalChars += word.length;
}

// Calculate the average word length
const avgWordLength = totalChars / words.length;

console.log('You entered:' +' ' +userInput);
console.log(`The average word length is ${avgWordLength}.`);