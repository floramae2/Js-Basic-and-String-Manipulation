const userInput = prompt("Please enter a text:");

// Divide the input text into an array of words
const words = userInput.toLowerCase().match(/\b\w+\b/g);

// Create an empty object to store the word count
const wordCount = {};

// Count the occurrences of each word in the array
for (const word of words) {
  if (wordCount[word]) {
    wordCount[word]++;
  } else {
    wordCount[word] = 1;
  }
}

// Find the most frequent word and its count
let maxCount = 0;
let mostFrequentWord = "";

for (const word in wordCount) {
  if (wordCount[word] > maxCount) {
    maxCount = wordCount[word];
    mostFrequentWord = word;
  }
}

console.log('You entered:' +" "+userInput);
console.log(`The most frequent word is "${mostFrequentWord}" with a count of ${maxCount}.`);