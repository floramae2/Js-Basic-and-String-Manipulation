// Function to encrypt a string using Caesar Cipher
function encrypt(text, shift) {
    let encryptedText = "";
    for (let i = 0; i < text.length; i++) {
        let charCode = text.charCodeAt(i);
        // Encrypt uppercase letters
        if (charCode >= 65 && charCode <= 90) {
            encryptedText += String.fromCharCode(((charCode - 65 + shift) % 26) + 65);
        }
        // Encrypt lowercase letters
        else if (charCode >= 97 && charCode <= 122) {
            encryptedText += String.fromCharCode(((charCode - 97 + shift) % 26) + 97);
        }
        // Leave non-alphabetic characters unchanged
        else {
            encryptedText += text.charAt(i);
        }
    }
    return encryptedText;
}

// Function to decrypt a string using Caesar Cipher
function decrypt(encryptedText, shift) {
    return encrypt(encryptedText, 26 - shift); // Decryption is just encryption with opposite shift
}

// Prompt the user to input a string to be encrypted
const userInput = prompt("Please enter a string to be encrypted:");

if (userInput !== null && userInput !== "") {
    // Define a shift value for encryption
    const shift = 3; // You can adjust the shift value as needed

    // Encrypt the input string
    const encryptedString = encrypt(userInput, shift);
    console.log("Encrypted String:", encryptedString);

    // Prompt the user to decrypt the encrypted string
    const decryptInput = confirm("Do you want to decrypt the encrypted string?");
    if (decryptInput) {
        // Decrypt the encrypted string
        const decryptedString = decrypt(encryptedString, shift);
        console.log("Decrypted String:", decryptedString);
    } else {
        console.log("Encryption process completed.");
    }
} else {
    console.log("Invalid input! Please enter a valid string.");
}
