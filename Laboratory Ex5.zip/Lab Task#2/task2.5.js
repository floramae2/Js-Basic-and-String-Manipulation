//two strings 
const string1 = "HELLO";
const string2 = "WORLD";

// use the < and > operators to compare the two strings
if (string1 < string2) {
  console.log(`${string1} comes before ${string2} alphabetically.`);
} else if (string1 > string2) {
  console.log(`${string1} comes after ${string2} alphabetically.`);
} else {
  console.log(`${string1} and ${string2} are the same string.`);
}