// Use the split() method to divide a string into an array of substrings.
const inputString = "apple,banana,orange";
const separator = ",";
const fruitArray = inputString.split(separator);

console.log(fruitArray);