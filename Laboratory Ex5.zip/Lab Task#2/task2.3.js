// String
const originalString = "Hello World!";

// Using length() method to find the length of the string
console.log("Length of the string:", originalString.length);

// Using toUpperCase() method to convert the string to uppercase
const upperCaseString = originalString.toUpperCase();
console.log("Uppercase string:", upperCaseString);

// Using toLowerCase() method to convert the string to lowercase
const lowerCaseString = originalString.toLowerCase();
console.log("Lowercase string:", lowerCaseString);

// Using substring() method to get a substring from index 0 to index 5 (exclusive)
const substring = originalString.substring(0, 5);
console.log("Substring:", substring);
