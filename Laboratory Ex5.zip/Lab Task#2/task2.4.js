// Variables
const name = "Flora Mae Requillo";
const age = 20;
const place = "Boyog Norte, Balilihan, Bohol";

// String interpolation using template literals
const message = `Hello, my name is ${name}. I am ${age} years old and I live in ${place}.`;

// Output 
console.log(message);
