// Prompt the user to input two strings
const string1 = prompt("Enter your First Name:");
const string2 = prompt("Enter the Surname:");

// Output the input strings
console.log("First Name:", string1);
console.log("Surname:", string2);
