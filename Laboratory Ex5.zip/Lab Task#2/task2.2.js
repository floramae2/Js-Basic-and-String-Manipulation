// Prompt the user to input two strings
const string1 = prompt("Enter your First Name:");
const string2 = prompt("Enter your Surname:");

// Concatenate the prompted strings using the "+" operator
const concatenatedString = string1 +" "+ string2;

// Output the concatenated string
console.log("Concatenated string:", concatenatedString);
