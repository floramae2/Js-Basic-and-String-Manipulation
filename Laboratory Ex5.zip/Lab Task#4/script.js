// Function to check password strength
// Prompt the user to input a password
const passwordInput = prompt("Please enter your password:");

function checkPasswordStrength(password) {
  
  // Initialize variables to track password criteria
  let lengthOK = false;
  let uppercaseOK = false;
  let lowercaseOK = false;
  let numberOK = false;
  let specialCharOK = false;

  // Check length
  if (password.length >= 8 && password.length <= 20) {
      lengthOK = true;
  }

  // Check for uppercase letters
  if (/[A-Z]/.test(password)) {
      uppercaseOK = true;
  }

  // Check for lowercase letters
  if (/[a-z]/.test(password)) {
      lowercaseOK = true;
  }

  // Check for numbers
  if (/\d/.test(password)) {
      numberOK = true;
  }

  // Check for special characters
  if (/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
      specialCharOK = true;
  }

  // Evaluate strength rating based on criteria
  let strength = 0;
  if (lengthOK) strength++;
  if (uppercaseOK) strength++;
  if (lowercaseOK) strength++;
  if (numberOK) strength++;
  if (specialCharOK) strength++;

  // Provide feedback message based on strength rating
  let feedbackMessage = "";
  switch (strength) {
      case 0:
      case 1:
          feedbackMessage = "Weak password";
          break;
      case 2:
          feedbackMessage = "Moderate password";
          break;
      case 3:
          feedbackMessage = "Fairly strong password";
          break;
      case 4:
      case 5:
          feedbackMessage = "Strong password";
          break;
  }

  return {
      strength: strength,
      feedback: feedbackMessage
  };
}

if (passwordInput !== null && passwordInput !== "") {
  // Check the strength of the password
  const result = checkPasswordStrength(passwordInput);

  // Display the strength rating and feedback message
  console.log("Strength Rating:", result.strength);
  console.log("Feedback:", result.feedback);
} else {
  console.log("Invalid input! Please enter a valid password.");
}
